#----------------------------------------------------------------------
# $Id: proxy.pm,v 1.3 2004/06/10 21:46:50 msoulier Exp $
#----------------------------------------------------------------------
# copyright (C) 2002 Mitel Networks Corporation
#----------------------------------------------------------------------

package esmith::FormMagick::Panel::proxy;

use strict;
use esmith::ConfigDB;
use esmith::FormMagick;

use constant SIGEVENT => '/sbin/e-smith/signal-event';
use constant TRUE  => 1;
use constant FALSE => 0;

our @ISA = qw(esmith::FormMagick Exporter);
our $VERSION = sprintf '%d.%03d', q$Revision: 1.3 $ =~ /: (\d+).(\d+)/;
our @EXPORT = qw(
    get_http_proxy_status get_smtp_proxy_status change_settings
    show_smtp_proxy_status
    );

=head1 NAME

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 FUNCTIONS

=cut

=head2 new

This is the class constructor.

=cut

sub new
{
    my $class = ref($_[0]) || $_[0];
    my $self = $class->SUPER::new();
    $self->{calling_package} = (caller)[0];

    # Lets not make this a global for a change. Globals bad. OO programming
    # good.
    my $db = esmith::ConfigDB->open
        or die "Failed to open configuration db!\n";

    $self->{db} = $db;

    return $self;
}

=head2 get_http_proxy_status

This method returns the current status of squid.

=cut

sub get_http_proxy_status
{
    my $self = shift;
    return $self->{db}->get_prop('squid', 'status');
}

=head2 get_smtp_proxy_status

This method returns the current status of the smtp proxy.

=cut

sub get_smtp_proxy_status
{
    my $self = shift;
    return $self->{db}->get_prop('smtpd', 'Proxy');
}

=head2 change_settings

This method takes the form submission and processes it.

=cut

sub change_settings
{
    my $self = shift;
    my $q = $self->{cgi};

    my $http_proxy_status = $q->param('http_proxy_status') || 'disabled';
    my $smtp_proxy_status = $q->param('smtp_proxy_status') || 'disabled';

    my $squid = $self->{db}->get('squid')
        or return $self->error('ERR_NO_SQUID_REC');
    # smtpd is allowed to not exist, as the relevant packages may not be
    # installed.
    my $smtpd = $self->{db}->get('smtpd') || undef;

    $squid->set_prop('status', $http_proxy_status);
    $smtpd->set_prop('Proxy', $smtp_proxy_status) if $smtpd;

    system(SIGEVENT, "proxy-update") == 0
        or return $self->error('ERR_PROXY_UPDATE_FAILED');

    return $self->success();
}

=head2 show_smtp_proxy_status

This function conditionally displays the smtp proxy widgets, if the
e-smith-email rpm is installed.

=cut

sub show_smtp_proxy_status
{
    my $self = shift;
    my $q = $self->{cgi};
    my @smtp_proxy_settings = qw(enabled disabled);
    my $default = $self->get_smtp_proxy_status();
    my %labels = (
        enabled  => $self->localise('ENABLED'),
        disabled => $self->localise('DISABLED'),
        );

    if (system('/bin/rpm -q e-smith-email > /dev/null') == 0)
    {
        # e-smith-email is installed. Show it.
        print $q->Tr(
            $q->td({-colspan => 2},
            $q->p($self->localise('SMTP_PROXY_STATUS_DESCRIPTION'))));
        print $q->Tr(
            $q->td({-class => 'sme-noborders-label'},
                $self->localise('SMTP_PROXY_STATUS_LABEL')),
            $q->td({-class => 'sme-noborders-content'},
                $q->popup_menu({-name => 'smtp_proxy_status',
                                -values => \@smtp_proxy_settings,
                                -default => $default,
                                -labels => \%labels})));

    }
    return undef;
}

1;
